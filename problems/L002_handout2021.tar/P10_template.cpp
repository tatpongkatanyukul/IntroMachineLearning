#include <iostream>
#include <iomanip>

using namespace std;

int main()
{

    float fuel, calori;
    float evL, evBBL;
    cout << "Fuel density (in kg/L): ";
    cin >> fuel;

    cout << "Calorific value (in MJ/kg): ";
    cin >> calori;

    evL = 0; // dummy; Write your code here!
    evBBL = 0; // dummy; Write your code here!

    cout << fixed << setprecision(2);
    cout << "This fuel has energy per volume of " << evL << " MJ/L." << endl;
    cout << "That is " << evBBL << " MJ/bbl.";


    return 0;
}
