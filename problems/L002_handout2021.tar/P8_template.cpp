#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float btu, time, price;
    float watt, energy, cost;

    cout << "Air conditioner power in BTU/hour: ";
    cin >> btu;
    cout << "Time duration having the a/c on in hour: ";
    cin >> time;
    cout << "Electricity price in baht/unit: ";
    cin >> price;

    /*
    Recall that 1 BTU/hour = 0.293 Watts.
    Energy = Power * Time.
    One (electrical consumption) unit = 1 k Watt hour.
    */

    watt = 0; // dummy; Write your code here!
    energy = 0; // dummy; Write your code here!
    cost = 0; // dummy; Write your code here!
    cout << "That will cost you " << setprecision(2) << fixed << cost << " baht." << endl;

    return 0;
}
