#include <iostream>
#include <iomanip>

using namespace std;

int main()
{

	float volt, mAh, mWh, joule;

	cout << "Battery voltage rating: ";
	cin >> volt;
	cout << "Capacity in mAh: ";
	cin >> mAh;

	mWh = 0; // dummy. Write your code here!
	joule =  0; // dummy. Write your code here!
	cout << "That is " << mWh << " mWh, or equivalent to " << joule << " joules.";

    return 0;
}

