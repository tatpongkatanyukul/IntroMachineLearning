/*
student: Turtle Kaveman
id: 631010001-0
*/

#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    float hp;
    float watts;
    cout << "Power in hp: ";
    cin >> hp;
    watts = 0; // write your code here
    cout << "Power " << hp << " hp is " << setprecision(2) << fixed << watts << " watts." << endl;

    return 0;
}
