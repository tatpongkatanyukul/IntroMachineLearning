#include <iostream>
#include "P5.h"

using namespace std;

int main(){
	float deg=0.0;
	float v;

	cout << "degree: ";
	cin >> deg;
	v = sine(deg);
	cout << "sine = " << v << endl;
	
	return 0;
}

