#include "P5.h"
#include <cmath>

float sine(float degree){
	
	float rad, s;
	// Write your code here
}

