"""
Name:
ID:
P3
Write a program to ask a user for any 3 names:
they can be user's idols or ones respectable,
then concatenate the first letter from each name together
with format [L1 L2 L3], and print out the result.
"""

def firstofeach(n1, n2, n3):
    s = n1[0] + n2[0] + n3[0]
    return s

if __name__ == '__main__':

    r = firstofeach('Jayasaro', 'Dejkunchon', 'Carroll')
    print(r)