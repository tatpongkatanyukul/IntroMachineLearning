"""
Name:
ID:
P
Write a program to ask a user for the user's names and
count the number of vowel alphabets (a, e, i, o, u) in the user's name.
For example, 'Alibaba' has 4 vowel alphabets.
"""

def vowel_count(txt):

    num_vowels = 0
    for c in txt:
        if c.lower() == 'a' or c.lower() == 'e' or c.lower() == 'i' or c.lower() == 'o' or c.lower() == 'u':
            num_vowels += 1

    return num_vowels


if __name__ == '__main__':

    r = vowel_count('Kruntep Mahanakorn Amornrattanakosin')
    print(r)