"""
Name:
ID:
P
Write a program to ask a user for (1) the user's motto and (2) a keyword.
Then, find the position of the keyword in the user’s motto.
"""

def find_key(motto, kword):

    pos = motto.find(kword)

    return pos


if __name__ == '__main__':

    r = find_key("For benefits and happiness of us all till the end of time",
                 "happiness")
    print(r)

    r = find_key("For benefits and happiness of us all till the end of time",
                 "courage")
    print(r)

    r = find_key("For benefits and happiness of us all till the end of time",
                 "of")
    print(r)
