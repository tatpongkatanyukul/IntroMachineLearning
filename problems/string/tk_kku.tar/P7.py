"""
Name:
ID:
P
Write a program to ask a user for (1) the user's motto and (2) a keyword.
Then, cut the text from beginning to the keyword (including the keyword)
and print it out. If there is no keyword in the motto, print nothing.
If there are multiple keywords found, print text to the first keyword.
"""

def to_key(motto, kword):

    msg = ""
    pos = motto.find(kword)
    if pos >= 0:
        msg = motto[:(pos+len(kword))]

    return msg


if __name__ == '__main__':

    r = to_key('For benefits and happiness of us all till the end of time',
               'happiness')
    print(r)

    r = to_key('For benefits and happiness of us all till the end of time',
               'of')
    print(r)

    r = to_key('For benefits and happiness of us all till the end of time',
               'wisdom')
    print(r)

    r = to_key('For benefits and happiness of us all till the end of time',
               'For')
    print(r)