"""
Name:
ID:
C major scale has 7 musical notes in an octave:
'A', 'B', 'C', 'D', 'E', 'F', and 'G'.
Write a function, named int2note,
to take an integer number from 1 to 7
and return the corresponding note.
"""

def int2note(midx):
    Cnotes = ' ABCDEFG'
    return Cnotes[midx]

if __name__ == '__main__':

    n = int2note(1)
    print(n)

    n = int2note(3)
    print(n)

    n = int2note(5)
    print(n)

    n = int2note(7)
    print(n)
