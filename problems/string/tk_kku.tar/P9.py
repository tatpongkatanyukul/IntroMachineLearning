"""
Name: dummy name
ID: 621011234-1
P9
Write a function named count_kmer taking two arguments: kmer and text,
then counting a number of kmers appear in the text and return the counting.
"""

# Style 1

def count_kmer(pattern, text):
   count = 0
   len_pat = len(pattern)

   for i in range(len(text)-len_pat+1):
       if text[i:i+len_pat] == pattern:
           count = count+1
   return count

# Style 2

# def count_kmer2(pattern, text):
#    count = 0
#    len_pat = len(pattern)
#    while len(text) >= len_pat:
#        if text[:len_pat] == pattern:
#            count += 1
#        text = text[1:]
#    return count



if __name__ == '__main__':

    r = count_kmer('ACTAT', 'ACAACTATGCATACTATCGGGAACTATC')
    print(r)

    r = count_kmer('AC', 'ACAACTATGCATACTATCGGGAACTATC')
    print(r)

    r = count_kmer('ATA', 'CGATATATCCATAG')
    print(r)
