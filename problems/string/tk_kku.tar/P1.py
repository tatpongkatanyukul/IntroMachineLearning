"""
Name:
ID:
P1
Write a function named format_name to take 2 arguments:
Firstname and Lastname.
The function concatenates them together with format Lastname, Firstname,
and return it as a single string.
"""

def format_name(Firstname, Lastname):
    s = Lastname + ', ' + Firstname
    return s


if __name__ == '__main__':

    r = format_name("Ajahn", "Brahm")
    print(r)