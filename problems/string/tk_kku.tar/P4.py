"""
Name:
ID:
P
Write a program to ask a user for any 3 names:
they can be user’s idols or ones respectable,
then concatenate the first 3 letters from each name together
IN ORDER with format [L11 L12 L13 L21 L22 L23 L31 L32 L33],
and print out the result.
"""

def concat3(name1, name2, name3):
    s = name1[0:3] + name2[0:3] + name3[0:3]
    return s


if __name__ == '__main__':

    r = concat3("Jayasaro", "Zinsser", "Carroll")
    print(r)