"""
Write a function named sailor_mate.
The function takes wind direction and desired heading direction,
determines the sailing strategy, and reports it.
The wind and desired directions are represented by clock notation,
e.g., "12:00" is northward, "3:00" o’clock is eastward,
"6:00" o’clock is southward, "9:00" is westward, etc.
The sailing strategy is one of the options: "tacking", "port close hauled",
 "port beam reach", "port broad reach", "run", "starboard broad reach",
 "starboard beam reach", "starboard close hauled".
"""

def clockToDegree(clock):
    hr, min = clock.split(':')
    hr = int(hr)
    min = int(min)

    deg = 0
    # Each hr is 30 degree. Each min is then 30/60 = 0.5 degree
    hr = hr % 12
    deg += hr * 30 + min * 0.5

    return deg

def sailor_mate(wind, boat):

    tol = 0.2 # 0.5 degree = 1 min

    W = clockToDegree(wind)
    B = clockToDegree(boat)

    #################################################################
    ## B - W + 180 is equivalent to rotating B and W for B =0, W = 180
    ## To handle cycle nature (i.e., 0 = 360), deg equiv deg + 360
    ## To standardize to range [0, 360),  (deg + 360) % 360
    #################################################################
    deg = (B - W + 180 + 360) % 360

    # debug
    # print('deg = %.1f'%deg, end=' ')

    strategy = 'tacking'
    if deg < 45 + tol: # or deg > 315:
        strategy = 'tacking'
    elif deg < 90 - tol:
        strategy = 'port close hauled'
    elif deg < 90 + tol:
        strategy = 'port beam reach'
    elif deg < 180 - tol:
        strategy = 'port broad reach'
    elif deg < 180 + tol:
        strategy = 'run'
    elif deg < 270 - tol:
        strategy = 'starboard broad reach'
    elif deg < 270 + tol:
        strategy = 'starboard beam reach'
    elif deg < 315 - tol:
        strategy = 'starboard close hauled'
    else:
        strategy = 'tacking'

    return strategy


if __name__ == '__main__':

    r = sailor_mate("9:00", "12:00")
    print("9:00", "12:00", r)

    ticks = ["12:00", "1:30", "1:31", "2:59", "3:00", \
             "3:01", "5:59", "6:00", "6:01", "8:59", "9:00", "9:01", \
             "10:29", "10:30"]

    for b in ticks:
        r = sailor_mate("6:00", b)
        print("6:00", b, r)



def test1():
    r = clockToDegree("12:00")
    print(r)

    r = clockToDegree("1:00")
    print(r)

    r = clockToDegree("3:00")
    print(r)

    r = clockToDegree("6:00")
    print(r)

    r = clockToDegree("9:00")
    print(r)

    r = clockToDegree("11:59")
    print(r)
