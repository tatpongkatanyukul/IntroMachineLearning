"""
Name:
ID:
P
Write a program to ask a user for (1) the user's motto and (2) a keyword.
Then, cut the text from beginning to the keyword (including the keyword)
and print it out. If there is no keyword in the motto, print nothing.
If there are multiple keywords found, print text to the first keyword.
"""

def k2k(motto, k1, k2):

    msg = ""
    pos1 = motto.find(k1)
    pos2 = motto.find(k2)

    if pos2 < pos1:

        pos1, pos2 = pos2, pos1
        k1, k2 = k2, k1

    if pos1 >= 0:
        msg = motto[pos1:(pos2+len(k2))]

    return msg


if __name__ == '__main__':

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'game', 'Life')
    print(r)

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'not', 'win')
    print(r)

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'win', 'not')
    print(r)

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'live', 'learn')
    print(r)

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'but', 'lessons')
    print(r)

    r = k2k('Life is not a game to win, but a melange of lessons to learn.',
            'lessons', 'learn')
    print(r)

