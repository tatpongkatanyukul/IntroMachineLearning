"""
Name: dummy name
ID: 621011234-0
P10

P10. In an old-time programming class,
to properly turn in a programming submission,
the submission file has to be named tAA_BBBBBBBBBB.tar,
where AA is a topic number and BBBBBBBBBB is a student id (10 digits)
without hyphen.
Write a function named is_valid to take in a submission file name
and return True when the name is a valid submission file name
and False when it is invalid.
"""

#import re

def is_valid(sname):

    # Style 0
    #r = re.match("t[0-9]{2}_[0-9]{10}\.tar", sname)
    #val = (r is not None)

    # Style 1
    nam, ext = sname.split('.')
    val = True
    if ext != 'tar':
        val = False

    if ' ' in nam:
        val = False

    if not '_' in nam:
        val = False
    else:
        topic, sid = nam.split('_')

        if topic[0] != 't':
            val = False

        if len(topic[1:]) != 2:
            val = False

        val = val and topic[1:].isnumeric()
        val = val and sid.isnumeric()

        if len(sid) != 10:
            val = False

    return val

if __name__ == '__main__':

    r = is_valid('t05_6210112341.tar')
    print(r)
    print(type(r))

    r = is_valid('t5_621011234-1.zip')
    print(r)

    r = is_valid('T5_621011234-1.zip')
    print(r)
