#include <iostream>
#include <cmath>

using namespace std;

int main(){

    float a, b, c;
    float magu, ua, ub, uc;

    cout << "Input vector (a, b, c): ";
    cin >> a >> b >> c;

    // Write your code here!!!
    magu = 0;
    ua = 0; 
    ub = 0; 
    uc = 0; 

    // Do not edit below this line.
    cout << "Unit vector (a, b, c) is ( " << ua << " , " << ub << " , " << uc << " )" << endl;

    return 0;
}