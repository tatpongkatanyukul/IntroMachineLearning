#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main(){
	
	float tol, pi=0, piold=0;
	
	cout << "tol: ";
	cin >> tol;
	
	float a, an, b, bn, t, p;
	
	// Step 1: Initialization
	a = 1;
	b = 1/sqrt(2);
	t = 1.0/4.0;
	p = 1;

	cout << setprecision(16) << fixed;
	
	do{

		an = a;
		bn = b;

		// Step 2
		a = (an + bn)/2;
		b = // write your code here
		t = // write your code here
		p = // write your code here

		// Step 3
		piold = pi;
		pi = // write your code here
	
		//cout << "a= " << a << "; b= " << b << "; t= " << t << "; p=" << p << "; pi= " << pi << endl;
		
	}while( abs(pi - piold) > tol );
	
	
	cout << "pi = " << pi << endl;
	return 0;
}