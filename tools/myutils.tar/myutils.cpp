/* src: https://computer.howstuffworks.com/c15.htm */
/* run this first:
   g++ -c -g myutils.cpp
*/

#include "myutils.h"

int aloha(int i)
{
    int j = i + 1;
    return j;
}

