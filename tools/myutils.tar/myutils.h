int aloha(int i);
