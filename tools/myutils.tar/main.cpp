/*
Demonstrate how to do a custom-made library.
https://computer.howstuffworks.com/c15.htm

g++ -c -g myutils.cpp -o myutils.o
g++ -c -g main.cpp -o main.o
g++ -o main.exe main.o myutils.o
*/


#include <iostream>
#include "myutils.h"

using namespace std;

int main()
{
    cout << "Hello CodeBlocks: test link!" << endl;
    int y;
    y = aloha(2020);
    cout << "Aloha " << y << endl;
    return 0;
}
