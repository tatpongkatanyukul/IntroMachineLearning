// turtle.h
#ifndef MyTurtle_h
#define MyTurtle_h

class MyTurtle {
  public:
    float posx, posy;   // (x,y)-position
    float head_rad;     // heading direction in radian
    float r, g, b;      // r,g,b-color

    MyTurtle();
    void color(float newr, float newg, float newb);
    void fd(int length);
    void mv(int length);
    void turn(float degree);
	void show_head();
};

#endif

int mydraw();

