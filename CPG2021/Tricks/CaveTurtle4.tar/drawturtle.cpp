/*
g++ -c -g mainturtle.cpp -o mainturtle.o
g++ -c -g drawturtle.cpp -o drawturtle.o
g++ -o goTurtle.exe drawturtle.o mainturtle.o  -lopengl32 -lglu32 -lgdi32

goTurtle.exe

*/

#include "turtle.h"


int draw_square(MyTurtle ts){
   ts.fd(100);
   ts.turn(90);
   ts.fd(100);
   ts.turn(90);
   ts.fd(100);
   ts.turn(90);
   ts.fd(100);

   return 0;
}

int mydraw(){

   float x1 = 0.0, y1 = 1.0;
   float x2 = 0.8, y2 = -0.5;
   float r=0, g=0, b=0;

	MyTurtle t = MyTurtle();

   t.color(0,0,1);

   draw_square(t);
   t.color(1,0,0);
   t.mv(300);
   t.show_head();
   
   return 0;
}